$(document).ready(function() {
    
    var link = crossroads.addRoute('', function(){

        query = window.location.search;
        urlParam = new URLSearchParams(query);
        var id = urlParam.get('id');

        $.ajax({
            type:"post",
            url:"https://kerbau.odaje.biz/getstaffbyid.php",
            data:'',
            cache:false,

            success:function(returnedData){

                myData = JSON.parse(returnedData);

                for(var i = 1; i <= myData.length; i++ ){
                    htmlText = htmlText + "<tr><td>Employee Number "+employeeNumber+"</td></tr><tr><td>Firstname "+firstName+"</td></tr><tr><td>Lastname "+lastName+"</td></tr><tr><td>Office Code "+officeCode+"</td></tr><tr><td>Phone Extension "+extension+"</td></tr><tr><td>Email Address "+email+"</td></tr><tr><td>Job Title "+jobTitle+"</td></tr><tr><td>Reports To "+reportsTo+"</td></tr>";
                    $('#maintable tbody').html(htmlText);
                }
                
            },
            
            error:function(){
                console.log("ajax error!");
                alert("Please contact admin!");
            }
        });
    });
});