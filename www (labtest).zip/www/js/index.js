$(document).ready(function() {
    
    var link = crossroads.addRoute('', function(){

        $.ajax({
            type:"post",
            url:"https://kerbau.odaje.biz/getstaff.php",
            data:'',
            cache:false,

            success:function(returnedData){
                myData = JSON.parse(returnedData);

                for(var i = 1; i <= myData.length; i++ ){
                    secondpage="<a href='secondpage.html?id="+employeeNumber+"'>"+email+"</a>"
                    htmlText = htmlText + "<tr><td>"+secondpage+"</td></tr>";
                    $('#maintable tbody').html(htmlText);
                }
                
            },
            
            error:function(){
                console.log("ajax error!");
                alert("Please contact admin!");
            }
        });
    });
});